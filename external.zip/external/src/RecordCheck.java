import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.Comparator;
/**
 * comaparing method for record
 * @author Nivishree Palvannan
 *@author Swati Lodha
 *@version 1.0
 */
public class RecordCheck implements Comparator<Record> { 
     /**
     * compare method for records
     * */
    @Override
    public int compare(Record rec1, Record rec2) {
        Double record1 = rec1.key();
        Double record2 = rec2.key();
        return record1.compareTo(record2);
    } 
    /**
     * comaring two records
     * @param rec1 byte[]
     * @param rec2 byet[]
     * @return boolean
     */
    public static int comparerecordHeap(byte[] rec1, byte[] rec2) {
        ByteBuffer buffer1 = ByteBuffer.wrap(
                Arrays.copyOfRange(rec1, 16 / 2, 16));
        Double rec1Double = buffer1.getDouble();
        ByteBuffer buffer2 = ByteBuffer.wrap(
                Arrays.copyOfRange(rec2, 16 / 2, 16));
        Double rec2Double = buffer2.getDouble();
        return rec1Double.compareTo(rec2Double);
    }
}