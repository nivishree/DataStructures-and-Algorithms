import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.util.*;
/**
 * 
 * @author nivip
 * @author swatil
 * @version 1.0
 * 
 * Merge sorting of records
 *
 */
public class MergeSort {
/**
 * min heap
 */
    protected PriorityQueue<Record> heapSorter;
    /**
     * number of runs
     */
    protected int runCounter;
/**
 * run information
 */
    protected LinkedList<RunInformation> runInfo;
/**
 * list of run info
 */
    protected LinkedList<Integer> runInfoList;
    /**
     * heap
     */
    protected MinHeap heap;
    private RandomAccessFile runFile;
    private RandomAccessFile inputFile;
    private IOBuffer outputBuffer;

/**
 * merge main
 * @throws IOException
 */
    public void mergeMain() throws IOException {
        if (runCounter == 1) {
            printToFile(runFile);
        }
        else {
            int runNums = 8;
            if (runCounter < 8) {
                runNums = runCounter;
            }
            loadToHeap(runNums);
        }
    }
    /**
     * util function
     * @param nextStart long
     * @throws IOException
     */
    public void checkUtil(long nextStart) throws IOException {
        Iterator<Record> iterator = heapSorter.iterator(); 
        while (iterator.hasNext()) { 
            Record minNode = heapSorter.poll();
            outputBuffer.writeToBuffer(minNode.getRecord());
        } 
        if (!outputBuffer.isEmpty()) {
            inputFile.write(Arrays.copyOfRange(
                        outputBuffer.array(), 0, 
                        outputBuffer.currentPosition()));
            outputBuffer.wipe();
        }
        if (runInfo.size() == 0) {
            printToFile(inputFile);
        }
        else {
            long end = inputFile.getFilePointer();
            boolean merged = true;
            RunInformation n = new RunInformation(runInfo.size(), 
                            nextStart, end, merged); 
            runRemain(n);
             
        }   
    }
    
/**
 * 
 * @param nextStart start next
 * @throws IOException
 */
    private void checkIfFinished(long nextStart) throws IOException {
        if (!outputBuffer.isEmpty()) {
            inputFile.write(Arrays.copyOfRange(
                        outputBuffer.array(), 0, 
                        outputBuffer.currentPosition()));
            outputBuffer.wipe();
        }
        checkUtil(nextStart);
    }
    
/**
 * 
 * @param n runs remain
 * @throws IOException
 */
    private void runRemain(RunInformation n) throws IOException {
        int nRunCount = 0;
        Iterator<RunInformation> j = runInfo.iterator(); 
        int i = 0;
        while (j.hasNext()) { 
            RunInformation r = j.next();
            if (!r.isAppended()) {
                r.setRun(i);
                nRunCount++;
                i++;
            }
        }
        runInfo.add(n);
        if (nRunCount == 0) {             
            Iterator<RunInformation> iter2 = runInfo.iterator(); 
            int c = 0;
            while (iter2.hasNext()) { 
                RunInformation runInfor = iter2.next();
                runInfor.setRun(c);
                runInfor.setAppend(false);
                c++;
            } 
            nRunCount = runInfo.size();
            RandomAccessFile temp = runFile;
            runFile = inputFile;
            inputFile = temp;
            runFile.seek(0);
            inputFile.seek(0);
            this.runCounter = runInfo.size();
            nRunCount = this.runCounter;
        }
        int runNum = 8;
        if (nRunCount < 8) {
            runNum = nRunCount;
        }
        loadToHeap(runNum);
    }
    
    /**
     * 
     * @param runNum run number
     * @throws IOException
     */
    private void merger(int runNum) throws IOException {
        long nextStart = inputFile.getFilePointer();
        outputBuffer.wipe();
        iterator();
        for (int i = runNum - 1; i >= 0; i--) {
            runInfo.remove(i);
        }
        checkIfFinished(nextStart);
    }
       
    /**
     * 
     * @param runNums number of run
     * @throws IOException
     */
    private void loadToHeap(int runNums) throws IOException {
        heapSorter = new PriorityQueue<Record>(runNums, 
                new RecordCheck());
        for (int i = 0; i < runNums; i++) {
            runInfoList.add(i);
            RunInformation runInf = runInfo.get(i); 
            nextBlkLoad(runInf);
        }
        merger(runNums);
    }
        
/**
 * 
 * @param numRun number of run
 * @param pointer current pointer position
 * @param lastValue end value
 * @throws IOException
 */
    private void loadRecordFromHeap(int numRun, int pointer, 
            int lastValue) throws IOException {
        byte[] myRecord = new byte[16];
        try {
            System.arraycopy(heap.arraysByte(), pointer, myRecord, 0, 16);
        }
        catch (ArrayIndexOutOfBoundsException exception) {
            System.out.println(exception);
        }
        
        Record rRecord = new Record(numRun, myRecord, pointer, lastValue);
        heapSorter.add(rRecord);
    }
  
    /**
     * 
     * @param runInf next run information
     * @throws IOException
     */
    private void nextBlkLoad(RunInformation runInf) throws IOException {
        long runLength = runInf.getRunEnd() - runInf.getPointer();
        long runNum = runInf.getRun();
        int eEnd = 0;
        if (runLength < 8192) {
            runFile.seek(runInf.getPointer());
            runFile.read(heap.arraysByte(), (int)(8192 * runNum), 
                            (int)runLength);
            runInf.setPointer(runFile.getFilePointer());
            eEnd = (int)(8192 * runNum + runLength);   
        }
        else {
            runFile.seek(runInf.getPointer());
            runFile.read(heap.arraysByte(), (int)(8192 * runNum), 
                            8192);
            runInf.setPointer(runFile.getFilePointer());
            eEnd = (int)(8192 * runNum + 8192);
        }
        int start = (int)(8192 * runNum);
        int temp = (int)runNum;
        loadRecordFromHeap(temp, start, eEnd);
    }
    
    /**
     * iterator
     * @throws IOException
     */
    public void iterator() throws IOException {
        while (runInfoList.size() > 0) {
            Record minValue = heapSorter.poll();
            outputBuffer.writeToBuffer(minValue.getRecord());
            minValue.addToCurrentPosition(16);
            if (outputBuffer.isFull()) {
                inputFile.write(Arrays.copyOfRange(
                            outputBuffer.array(), 0, 
                            outputBuffer.currentPosition()));
                outputBuffer.wipe();
            }
            int nBlk = minValue.getBlockCount();
            int sBlk = minValue.getEndPointer() - 
                minValue.getCurrentPointerPosition(); 
            boolean isRefill = false;
            boolean runReader = true;
            RunInformation runInf = runInfo.get(nBlk);
            long runLength = runInf.getRunEnd() - runInf.getPointer();
            if (sBlk == 0 && runInfoList.contains(nBlk)) {  
                isRefill = true;
                if (runLength < 8192) {
                    long end = (nBlk * 8192) + runLength;
                    minValue.setEndPointer((int)end);
                }
                if (runLength == 0) { 
                    runInfoList.remove((Integer)nBlk);
                    runReader = false;
                }
                else {
                    nextBlkLoad(runInf);
                }
            }
            if (runReader && !isRefill) {
                loadRecordFromHeap(nBlk, 
                    minValue.getCurrentPointerPosition(),
                    minValue.getEndPointer());
            }
        }
    }
    
    /**
     * getIdKeyInfo
     * @param bytes the byte array to convert
     * @return the key value
     */
    private double getIdKeyInfo(byte[] bytes) {
        byte[] idBytes = Arrays.copyOfRange(bytes, 0, 
                            16 / 2);
        byte[] keyBytes = Arrays.copyOfRange(bytes, 
                            16 / 2, 16);
        long recId = ByteBuffer.wrap(idBytes).getLong();
        double recKey = ByteBuffer.wrap(keyBytes).getDouble();
        System.out.print(recId + " " + recKey);
        return recKey;
    }
    
    /**
     * constructor
     * @param controller controller
     * @throws IOException
     */
    public MergeSort(Controller controller) throws IOException {
        runInfo = controller.getRunInfo();
        heap = controller.minHeap();
        runFile = controller.runFile();
        inputFile = controller.inputFile();
        controller.inputBuffer().wipe();
        runCounter = runInfo.size();
        outputBuffer = controller.outputBuffer();
        runInfoList = new LinkedList<Integer>();
        runFile.seek(0);
        inputFile.seek(0);   
    }
       /**
        * @param file last file
        * @throws IOException
        */
    private void printToFile(RandomAccessFile file) 
           throws IOException {
        file.seek(0);
        int n = 0;
        while (8192 * n != file.length()) { //8192*n
            byte[] b = new byte[16];
            file.read(b);
            n++;
            if (n < 0) {
                break;
            }
            file.seek(8192 * n); // check negative
            getIdKeyInfo(b);
            if (n % 5 == 0) {
                System.out.println();
            }
            else {
                System.out.print(' ');
            }
        }
    }
}
 
// final block is not complete 512 -- 200 rec shld also consider - edge