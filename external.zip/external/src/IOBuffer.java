import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Arrays;

/**
 * IO buffer class which is used
 * to build in and out buffers
 * @author Nivishree Palvannan
 * @author Swati Lodha
 * @version 1.0
 *
 */
public class IOBuffer {
    private byte[] buffer;
    private int recNum;
    private int point;
/**
 * Constructor
 */
    public IOBuffer() {
        buffer = new byte[8192];
        recNum = 0;
        point = 0;
    }
    
    /**
     *cleans the buffer
     */
    public void wipe() {
        recNum = 0;
        point = 0;
    }
    

    /**
     * 
     * @param file file
     * @throws IOException
     */
    public void loadBlock(RandomAccessFile file) throws IOException {
        wipe();
        long previous = file.getFilePointer();
        file.read(buffer);
        long difference = file.getFilePointer() - previous;
        recNum = (int)difference / 16;
        point = 0;
    }
    
/**
 * 
 * @param record reco
 */
    public void writeToBuffer(byte[] record) {
        if (!isFull()) {
            System.arraycopy(record, 0, buffer, point, 16);
            point += 16;
            recNum++;
        }
    }
    
    /**
     * @return the record
     */
    public byte[] reader() {
        if (point >= 8192 || point < 0) {
            return null;
        }
        point += 16;
        return Arrays.copyOfRange(buffer, point - 16, point);
    }
    
    /**
     * @return boolean 
     */
    public boolean isFinished() {
        return point == 8192;
    }

    
    /**
     * @return the current position 
     */
    public int currentPosition() {
        return point;
    }
    
    /**
     * @return arr
     */
    public byte[] array() {
        return buffer;
    }
    
    /**
     * @return full or not checking
     */
    public boolean isFull() {
        return recNum * 16 == 8192;
    }
    
    /**
     * @return checking emptiness
     */
    public boolean isEmpty() {
        return recNum == 0;
    }
    
}
