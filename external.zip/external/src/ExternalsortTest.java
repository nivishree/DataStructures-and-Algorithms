import java.io.IOException;

import org.junit.Test;

import student.TestCase;
/**
 * 
 *@author Nivishree Palvannan
 *@author Swati Lodha
 * @version 1.0
 *
 */
public class ExternalsortTest extends TestCase {
/**
 * main test for external sort
 * @throws IOException
 */
    @Test
    public void testMain() throws IOException {
        String[] args = {"Data/sampleInput16.bin"};
        @SuppressWarnings("unused")
        Externalsort ext = new Externalsort();
        Externalsort.main(args);
        String[] args2 = {"test2.bin", "20"};
        Genfile.main(args2);
        Controller sc = new Controller("test2.bin");
        Handler handler = new Handler(sc);
        handler.handler();
        Controller controller = new Controller(args[0]);
        assertFalse(controller.minHeap().isEmpty());
        assertTrue(controller.inputBuffer().isEmpty());
        assertTrue(controller.outputBuffer().isEmpty());

    }
}
