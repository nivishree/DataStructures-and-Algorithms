
import java.io.*;
import java.util.*;
import java.math.*;

/**

 * @author CS PROF
 * @version 1.0
 * 
 * This is a provided file to generate bin files for testing
 *
 */
public class Genfile {

    static private Random value = new Random();
    
    
    /**
     * @return a random long value
     */
    static long randLong() {
        return value.nextLong();
    }
    
    /**
     * @return a random double value
     */
    static double randDouble() {
        return value.nextDouble();
    }
    
    /**
     * @param args arguments for the filename to generate and its size
     * @throws IOException
     */
    public static void main(String[] args) throws IOException {
        long val;
        double val2 ;
    
        int filesize = Integer.parseInt(args[1]); // Size of file in blocks
        DataOutputStream file = new DataOutputStream(
            new BufferedOutputStream(new FileOutputStream(args[0])));
    
        for (int i = 0; i < filesize; i++) {
            for (int j = 0; j < 512; j++) {
                val = (long)(randLong());
                file.writeLong(val);
                val2 = (double)(randDouble());
                file.writeDouble(val2);
            }
        }

        file.flush();
        file.close();
    }
}
