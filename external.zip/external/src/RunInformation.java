/**
 * 
 *@author Nivishree Palvannan
 *@author Swati Lodha
 * @version 1.0
 *
 */
public class RunInformation {
    private boolean appended;
    private int runNumber;
    private long pointer;
    private long rStart;
    private long rEnd;
    
/**
 * 
 * @param runValue run vlaue 
 * @param runStart end value
 * @param runEnd start value
 * @param t t
 */
    RunInformation(int runValue, long runStart, long runEnd, boolean t) {
        runNumber = runValue;
        pointer = runStart;
        rStart = runStart;
        rEnd = runEnd;
        appended = t;
    }
    
/**
 * 
 * @param start value
 */
    public void setRunStart(int start) {
        rStart = start;
    }
    
/**
 * 
 * @return end
 */
    public long getRunEnd() {
        return rEnd;
    }
    
/**
 * 
 * @param end end val
 */
    public void setRunEnd(int end) {
        rEnd = end;
    }
     

    /**
     * 
     * @return boolean
     */
    public boolean isAppended() {
        return appended;
    }
    
  /**
   * 
   * @param isAppend boolen
   */
    public void setAppend(boolean isAppend) {
        appended = isAppend;
    }
    
  /**
   * @return number
   */
    public long getRun() {
        return runNumber;
    }
    
/**
 * 
 * @param run int
 */
    public void setRun(int run) {
        runNumber = run;
    }
/**
 * get current pointer
 * @return pointer
 */
    public long getPointer() {
        return pointer;
    }
    
/**
 * set current position
 * @param value pointer
 */
    public void setPointer(long value) {
        pointer = value;
    }
    
/**
 * 
 * @return start
 */
    public long getrunStart() {
        return rStart;
    }

}
