import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Arrays;
import java.util.LinkedList;

/**
 * 
 * @author Nivishree Palvannan
 * @author Swati Lodha
 *@version 1.0
 */
public class Handler {


    private IOBuffer inputBuffer;
    private IOBuffer outputBuffer;
    private MinHeap minHeap;
    private long runStart;
    private long runEnd;
    private int nRun;
    private LinkedList<RunInformation> runs;
    private RandomAccessFile inputFile;
    private RandomAccessFile outputFile;


/**
 * constructor for handler class
 * @param controller controller instance
 * @throws IOException
 */
    public Handler(Controller controller) throws IOException {
        runs = controller.getRunInfo();
        minHeap = controller.minHeap();
        inputBuffer = controller.inputBuffer();
        outputBuffer = controller.outputBuffer();
        inputFile = controller.inputFile();
        outputFile = controller.runFile();
        runStart = 0;
        runEnd = 0;
    }

/**
 * handler function for sorting initialization
 * @throws IOException
 */
    public void handler() throws IOException {
        runStart = outputFile.getFilePointer();
        int nextRunCount = 0;
        while (inputFile.getFilePointer() != inputFile.length()) { 
            inputBuffer.loadBlock(inputFile);
            nextRunCount = handlerUtil();
        } 
        writeBufferToFile(); // writing   buffer  to file
        for (int i = 0; i <= nextRunCount; i += nextRunCount) {
            while (!minHeap.isEmpty()) {
                if (outputBuffer.isFull()) {
                    writeBufferToFile();
                }
                outputBuffer.writeToBuffer(minHeap.removemin());
            }
            
            writeBufferToFile();
            updateRun();
            
            if (nextRunCount == 0) {
                i++;
            }
            else {
                minHeap.buildHeap(nextRunCount);
            }
        }
        inputBuffer.wipe();
        
    }
/**
 * writng to the file from buffer
 * @throws IOException
 */
    private void writeBufferToFile() throws IOException {
        if (!outputBuffer.isEmpty()) {
            outputFile.write(Arrays.copyOfRange(outputBuffer.array(), 
                            0, outputBuffer.currentPosition()));
            outputBuffer.wipe();
        }
    }
    
    /**
     * utility for handler function
     * @return int
     * @throws IOException 
     */
    public int  handlerUtil() throws IOException {
        int c = 0;
        while (!inputBuffer.isFinished()) {
            if (minHeap.isEmpty()) {
                writeBufferToFile();           
                updateRun();
                minHeap.buildHeap(4096);
                c = 0;
            }
            else if (outputBuffer.isFull()) {
                writeBufferToFile();
            }
            byte[] minVal = minHeap.getRec(0);
            outputBuffer.writeToBuffer(minVal);
            byte[] buf = inputBuffer.reader();
            if (RecordCheck.comparerecordHeap(buf, minVal) > 0 ) {
                minHeap.modify(0, buf);
            }
            else {
                minHeap.removemin(buf);
                c++;
            } 
        } 
        return c;
    }
/**
 * updating run
 * @throws IOException
 */
    private void updateRun() throws IOException {
        runEnd = outputFile.getFilePointer();
        if (runStart != runEnd) {
            RunInformation n = new RunInformation(nRun,
                runStart, runEnd, false);
            runs.add(n);
            nRun++;
            runStart = runEnd;
        }
    }
    /**
     * merge sorting
     * @param controller controller instance
     * @throws IOException
     */
    public void merger(Controller controller) throws IOException {

        MergeSort merge = new MergeSort(controller);
        merge.mergeMain();
        controller.inputFile().close();
        controller.runFile().close();
    }
    
}
