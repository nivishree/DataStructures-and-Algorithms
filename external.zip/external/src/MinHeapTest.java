import student.TestCase;

import java.nio.ByteBuffer;
import java.util.Arrays;
/**
 * Min Heap Tester
 *@author Nivishree Palvannan
 *@author Swati Lodha
 *@version 1.0
 */
public class MinHeapTest extends TestCase {
    
    
    /**
     * Test method
     */
    public void minHeapTest() {
        MinHeap m = new MinHeap();
        byte[] array = changeToByteArr(16, 9);
        byte[] array2 = changeToByteArr(17, 6);
        byte[] record = new byte[32];
        System.arraycopy( array, 0, record, 0, 16);
        System.arraycopy( array2, 0, record, 16, 16);
        MinHeap minHeap = new MinHeap(record, 2, 4096);
        double val = m.convertToNumber(minHeap.getRec(0));
        assertEquals((int)val, 6);
    }


    /**
     * Test method
     */
    public void minHeapSizeTest() {
        MinHeap m = new MinHeap();
        byte[] byteArr = changeToByteArr(15, 8);
        byte[] byteArr2 = changeToByteArr(18, 5);
        byte[] record = new byte[32];
        System.arraycopy( byteArr, 0, record, 0, 16);
        System.arraycopy( byteArr2, 0, record, 16, 16);
        MinHeap myHeap = new MinHeap(record, 2, 4096);
        assertEquals(myHeap.minHeapSize(), 2);
    }


    /**
     * Test method
     */
    public void testCompareRecords() {
        MinHeap m = new MinHeap();
        byte[] b = changeToByteArr(15, 8);
        byte[] b2 = changeToByteArr(18, 5);
        byte[] record = new byte[32];
        System.arraycopy( b, 0, record, 0, 16);
        System.arraycopy( b2, 0, record, 16, 16);
        MinHeap myHeap = new MinHeap(record, 2, 4096);
        assertEquals(RecordCheck.comparerecordHeap(b, b2), 1);
    }
    /**
     * @param recId id
     * @param recKey to byte
     * @return record
     */
    public byte[] changeToByteArr(long recId, double recKey) {
        byte[] arr1 = new byte[16 / 2];
        byte[] arr2 = new byte[16 / 2];
        ByteBuffer.wrap(arr1).putLong(recId);
        ByteBuffer.wrap(arr2).putDouble(recKey);
        byte[] record = new byte[16];
        System.arraycopy( arr1, 0, record, 0, 16 / 2);
        System.arraycopy( arr2, 0, record, 16 / 2, 16 / 2);
        return record;
    }

    /**
     * Test method
     */
    public void testLeaf() {
        MinHeap m = new MinHeap();
        byte[] byteArr = changeToByteArr(15, 8);
        byte[] byteArr2 = changeToByteArr(18, 5);
        byte[] record = new byte[32];
        System.arraycopy( byteArr, 0, record, 0, 16);
        System.arraycopy( byteArr2, 0, record, 16, 16);

        MinHeap myHeap = new MinHeap(record, 2, 4096);
        assertTrue(myHeap.isLeaf(16));
    }


    /**
     * Test method for Leftchild
     */
    public void testChildL() {
        MinHeap m = new MinHeap();
        byte[] byteArr = changeToByteArr(15, 8);
        byte[] byteArr2 = changeToByteArr(18, 5);
        byte[] record = new byte[32];
        System.arraycopy( byteArr, 0, record, 0, 16);
        System.arraycopy( byteArr2, 0, record, 16, 16);

        MinHeap myHeap = new MinHeap(record, 2, 4096);
        assertEquals(myHeap.leftchild(0), 16);
    }


    /**
     * Test method for Rightchild
     */
    public void testChildR() {
        MinHeap m = new MinHeap();
        byte[] byteArr = changeToByteArr(15, 8);
        byte[] byteArr2 = changeToByteArr(18, 5);
        byte[] byteArr3 = changeToByteArr(14, 2);
        byte[] record = new byte[48];
        System.arraycopy( byteArr, 0, record, 0, 16);
        System.arraycopy( byteArr2, 0, record, 16, 16);
        System.arraycopy( byteArr3, 0, record, 32, 16);

        MinHeap myHeap = new MinHeap(record, 3, 4096);

        assertEquals(myHeap.rightchild(0), 32);
    }


    /**
     * Test method for Parent
     */
    public void testParent() {
        MinHeap m = new MinHeap();
        byte[] byteArr = changeToByteArr(15, 8);
        byte[] byteArr2 = changeToByteArr(18, 5);
        byte[] record = new byte[32];
        System.arraycopy( byteArr, 0, record, 0, 16);
        System.arraycopy( byteArr2, 0, record, 16, 16);

        MinHeap myHeap = new MinHeap(record, 2, 4096);
        assertEquals(myHeap.parent(16), 0);
    }


    /**
     * Test method for BuildHeap
     */
    public void testHeapMake() {
        MinHeap m = new MinHeap();
        byte[] b1 = changeToByteArr(15, 8);
        byte[] b2 = changeToByteArr(18, 5);
        byte[] b3 = changeToByteArr(15, 8);
        byte[] b4 = changeToByteArr(18, 5);
        byte[] b5 = changeToByteArr(15, 8);
        byte[] record = new byte[80];
        System.arraycopy( b1, 0, record, 0, 16);
        System.arraycopy( b2, 0, record, 16, 16);
        System.arraycopy( b3, 0, record, 32, 16);
        System.arraycopy( b4, 0, record, 48, 16);
        System.arraycopy( b5, 0, record, 64, 16);
        MinHeap myHeap = new MinHeap(record, 5, 4096);
        assertEquals(myHeap.minHeapSize(), 5);
        assertEquals(myHeap.parent(32), 0);
    }


    /**
     * Test method for Siftdown
     */
    public void testSiftdown() {
        MinHeap m = new MinHeap();
        byte[] b1 = changeToByteArr(15, 2);
        byte[] b2 = changeToByteArr(18, 3);
        byte[] b3 = changeToByteArr(15, 55);
        byte[] b4 = changeToByteArr(18, 7);
        byte[] b5 = changeToByteArr(15, 8);
        byte[] record = new byte[80];
        System.arraycopy( b1, 0, record, 0, 16);
        System.arraycopy( b2, 0, record, 16, 16);
        System.arraycopy( b3, 0, record, 32, 16);
        System.arraycopy( b4, 0, record, 48, 16);
        System.arraycopy( b5, 0, record, 64, 16);
        MinHeap myHeap = new MinHeap(record, 5, 4096);
        assertTrue(Arrays.equals(myHeap.getRec(0),
                    changeToByteArr(15, 2)));
        assertTrue(Arrays.equals(myHeap.getRec(16),
                    changeToByteArr(18, 3)));
    }


    /**
     * Test method for Removemin
     */
    public void testRemovemin() {
        MinHeap m = new MinHeap();
        byte[] arr1 = changeToByteArr(15, 7);
        byte[] arr2 = changeToByteArr(18, 6);
        byte[] arr3 = changeToByteArr(15, 4);
        byte[] arr4 = changeToByteArr(18, 8);
        byte[] arr5 = changeToByteArr(15, 5);
        byte[] record = new byte[80];
        System.arraycopy( arr1, 0, record, 0, 16);
        System.arraycopy( arr2, 0, record, 16, 16);
        System.arraycopy( arr3, 0, record, 32, 16);
        System.arraycopy( arr4, 0, record, 48, 16);
        System.arraycopy( arr5, 0, record, 64, 16);
        MinHeap minHeap = new MinHeap(record, 5, 4096);
        assertTrue(Arrays.equals(minHeap.getRec(0), changeToByteArr(15, 4)));
        minHeap.removemin();
        assertTrue(Arrays.equals(minHeap.getRec(0), changeToByteArr(15, 5)));
        minHeap.removemin();
        assertTrue(Arrays.equals(minHeap.getRec(0), changeToByteArr(18, 6)));
        minHeap.removemin();
        assertTrue(Arrays.equals(minHeap.getRec(0), changeToByteArr(15, 7)));
        minHeap.removemin();
        assertTrue(Arrays.equals(minHeap.getRec(0), changeToByteArr(18, 8)));

        byte[] a1 = changeToByteArr(15, 7);
        byte[] a2 = changeToByteArr(18, 6);
        byte[] a3 = changeToByteArr(15, 4);
        byte[] a4 = changeToByteArr(18, 8);
        byte[] a5 = changeToByteArr(15, 5);
        byte[] r = new byte[80];
        System.arraycopy( a1, 0, r, 0, 16);
        System.arraycopy( a2, 0, r, 16, 16);
        System.arraycopy( a3, 0, r, 32, 16);
        System.arraycopy( a4, 0, r, 48, 16);
        System.arraycopy( a5, 0, r, 64, 16);
        MinHeap h = new MinHeap(r, 5, 4096);
        assertTrue(Arrays.equals(h.getRec(0), changeToByteArr(15, 4)));
        byte[] t1 = changeToByteArr(15, 2);
        h.removemin(t1);
        assertTrue(Arrays.equals(h.getRec(0), changeToByteArr(15, 5)));
        h.removemin(t1);
        assertTrue(Arrays.equals(h.getRec(0), changeToByteArr(18, 6)));
        h.removemin(t1);
        assertTrue(Arrays.equals(h.getRec(0), changeToByteArr(15, 7)));
        h.removemin(t1);
        assertTrue(Arrays.equals(h.getRec(0), changeToByteArr(18, 8)));
    }

}
