import java.nio.ByteBuffer;
import java.util.*;

/**
 * 
 *@author Nivishree Palvannan
 *@author Swati Lodha
 * @version 1.0
 *
 */
public class MinHeap {

    private byte[] byteArray; 
    private int size;
    private int capacity; 

/**
 * Constructor
 * @param array arr
 * @param n n
 * @param m m
 */
    public MinHeap(byte[] array, int n, int m) { 
        byteArray = array;  
        capacity = n;  
        size = m;
        makeHeap(); 
    }
    
    
  /**
   * Constructor without args
   */
    public MinHeap() { 
        byteArray = new byte[4096];  
        capacity = 4096;  
        size = 4096;
    }
    
  /**
   * 
   * @param position position
   * @return array
   */
    public byte[] getRec(int position) {
        return Arrays.copyOfRange(byteArray, position, position + 16);
    }

    /**
     * @return heap size
     */
    public int minHeapSize() {
        return capacity;
    }

    /**
     * @return array
     */
    public byte[] arraysByte() {
        return byteArray;
    }

/**
 * Whether leaf of not
 * @param pos position
 * @return boolean
 */
    public boolean isLeaf(int pos) {
        return ((pos / 16) >= capacity / 2) && 
               ((pos / 16) < capacity);
    }
    
    /**
     * @return if the number of records in heap is zero
     */
    public boolean isEmpty() {
        return capacity == 0;
    }

    /**
     * 
     * @param pos left
     * @return position of child in left
     */
    public int leftchild(int pos) {
        if ((pos / 16) >= capacity / 2) {
            return -1;
        }
        return (2 * pos) + 16;
    }

    /**
     * 
     * @param pos position
     * @return the position of the right child
     */
    public int rightchild(int pos) {
        if ((pos / 16) >= (capacity - 1) / 2) {
            return -1;
        }
        return (2 * pos) + 2 * 16;
    }

    /**
     *
     * @param pos parent
     * @return parent position
     */
    public int parent(int pos) {
        if ((pos / 16) <= 0) {
            return -1;
        }
        return (pos / 16 - 1) / 2;
    }

    /**
     * Heapify contents of heap
     */
    public void makeHeap() {
        int i = (capacity / 2 - 1) * 16;
        for (; i >= 0; i -= 16) {
            siftdown(i);
        }
    }
/**
 * 
 * @param recordsLeft left records
 */
    public void buildHeap(int recordsLeft) {
        if (recordsLeft < size) {
            int start = (size - recordsLeft) * 16;
            System.arraycopy(byteArray, start, byteArray, 0, recordsLeft * 16);
        }
        capacity = recordsLeft;
        makeHeap();
    }


    /**
     * 
     * @param position to shift
     */
    private void siftdown(int pos) {
        if ((pos < 0) || ((pos / 16) >= capacity)) {
            return;
        }
        while (!isLeaf(pos)) {
            int j = leftchild(pos);
            byte[] a = Arrays.copyOfRange(byteArray, j, j + 16);
            byte[] b = Arrays.copyOfRange(byteArray, 
                                j + 16, j + 2 * 16);
            if (((j / 16) < (capacity - 1)) 
                            && (RecordCheck.comparerecordHeap(a, b) >= 0)) {
                j += 16;
            }
            byte[] c = Arrays.copyOfRange(byteArray, pos, pos + 16);
            byte[] d = Arrays.copyOfRange(byteArray, j, j + 16);
            if (RecordCheck.comparerecordHeap(c, d) <= 0) {
                return;
            }
            swap(j, pos);
            pos = j;
            
        }
    }
    
/**
 * 
 * @param postion1 position1
 * @param position2 postion2
 */
    private void swap(int postion1, int position2) {
        byte[] temp = Arrays.copyOfRange(byteArray, postion1, postion1 + 16);
        int i = postion1;
        int j = position2;
        for (; i < postion1 + 16; i++, j++) {
            byteArray[i] = byteArray[j];
        }
        i = 0;
        j = position2;
        for (; j < position2 + 16; j++, i++) {
            byteArray[j] = temp[i];
        }  
    }

    /**
     *
     * @return min
     */
    public byte[] removemin() {
        if (capacity == 0) {
            return null;
        }
        swap(0, (--capacity) * 16);
        if (capacity != 0) {
            siftdown(0);
        }
        return Arrays.copyOfRange(byteArray, 
                                  capacity * 16, 
                                  capacity * 16 + 16);
    }
    

    /**
     *
     * @param b replacing
     * @return min
     */
    public byte[] removemin(byte[] b) {
        if (capacity == 0) {
            return null;
        }
        swap(0, (--capacity) * 16);
        if (capacity != 0) {
            siftdown(0);
        }
        System.arraycopy(b, 0, byteArray, capacity * 16, 16);
        return Arrays.copyOfRange(byteArray, 
                                  capacity * 16, 
                                  capacity * 16 + 16);
    }

    /**
     * Modify 
     * @param position new place
     * @param newValue 
     */
    public void modify(int position, byte[] newValue) {
        if ((position < 0) || (position >= capacity * 16)) {
            return; 
        }
        System.arraycopy(newValue, 0, byteArray, position, 16);
        upgrade(position);
    }

    /**
     * 
     * @param position position
     */
    private void upgrade(int position) {
        while ((position > 0) && 
               (RecordCheck.comparerecordHeap(
                      Arrays.copyOfRange(byteArray, position, position + 16), 
                      Arrays.copyOfRange(byteArray, parent(position), 
                      parent(position) + 16)) < 0)) {
            swap(position, parent(position));
            position = parent(position);
        }
        if (capacity != 0) {
            siftdown(position);
        }
    }
    
    
    /**
     * Testing function
     * @param bytes to key
     * @return key
     */
    public double convertToNumber(byte[] bytes) {
        byte[] keyBytes = Arrays.copyOfRange(bytes, 
            16 / 2, 16);
        double key = ByteBuffer.wrap(keyBytes).getDouble();
        return key;
    }
    
}
