import java.nio.ByteBuffer;
import java.util.Arrays;

/**
 * @author Nivishree Palvannan
 * @author Swati Lodha
 * @version 1.0
 *
 *  This is the record class which has all info 
 *  on record and block
 */
public class Record {

    private int blkNum;
    private int currentPointer;
    private int start;
    private int recEnd;
    private double key;
    private byte[] rec;
    
 /**
  * Record
  * @param block 512 record
  * @param recArray array
  * @param pointer current
  * @param endPointer end
  */
    Record(int block, byte[] recArray, int pointer, int endPointer) {
        blkNum = block;
        start = block * 8192;
        recEnd = endPointer;
        byte[] keyBytes = Arrays.copyOfRange(recArray, 8, 16);
        double keyVal = ByteBuffer.wrap(keyBytes).getDouble();
        key = keyVal;
        rec = recArray;
        currentPointer = pointer;
    }
    
    /**
     * 
     * @return block count
     */
    public int getBlockCount() {
        return blkNum;
    }
    
    /**
     * 
     * @param block count
     */
    public void setBlockCount(int block) {
        blkNum = block;
    }
    /**
    *
    * @param end pos
    */
    public void setEndPointer(int end) {
        recEnd = end;
    }
   
   /**
    * 
    * @param increment value
    */
    public void addToCurrentPosition(int increment) {
        currentPointer += increment;
    }
   
   /**
    * @return the key value
    */
    public double key() {
        return key;
    }
    /**
     * 
     * @return record 
     */
    public byte[] getRecord() {
        return rec;
    }
    
   
    /**
     * 
     * @return start
     */
    public int getStartPointer() {
        return start;
    }
    
    /**
     *
     * @param startPoint pos
     */
    public void setStartPointer(int startPoint) {
        this.start = startPoint;
    }
    
    /**
     *
     * @return end
     */
    public int getEndPointer() {
        return recEnd;
    }
    /** 
     * 
     * @return cuur pos
     */
    public int getCurrentPointerPosition() {
        return currentPointer;
    }
    
    /**
     *
     * @param cur the location to set the node to
     */
    public void setCurrentPointerPosition(int cur) {
        currentPointer = cur;
    }
    

    

}

