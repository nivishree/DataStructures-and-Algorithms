import static org.junit.Assert.*;
import java.io.IOException;
import student.TestCase;

import org.junit.Test;
/**
 * Test class for merge sort
 *@author Nivishree Palvannan
 *@author Swati Lodha
 *@version 1.0
 */
public class MergeSortTest  extends TestCase {
     /**
     * Test method
     * @throws IOException 
     */
    @Test
    public void test() throws IOException {
        String[] args = {"test13.bin", "10"};
        Genfile.main(args);
        Controller controller = new Controller("test13.bin");
        Handler handler = new Handler(controller);
        handler.handler();
        MergeSort merge = new MergeSort(controller);
        merge.mergeMain();
        assertTrue(controller.inputBuffer().isEmpty());
        assertTrue(controller.outputBuffer().isEmpty());
        assertTrue(merge.heapSorter.isEmpty());
        assertTrue(merge.runInfo.isEmpty());
        String[] args2 = {"test14.bin", "100"};
        Genfile.main(args2);
        Controller controller2 = new Controller("test14.bin");
        Handler handler2 = new Handler(controller2);
        handler2.handler();
        MergeSort merge2 = new MergeSort(controller2);
        merge2.mergeMain();
        assertTrue(merge2.heapSorter.isEmpty());
        assertTrue(merge2.runInfo.isEmpty());
        assertTrue(controller.inputBuffer().isEmpty());
        assertTrue(controller.outputBuffer().isEmpty());
    }
     /**
     * Test method
     * @throws IOException 
     */
    @Test
    public void testMergeSort() throws IOException {
        String[] args = {"test12.bin", "10"};
        Genfile.main(args);
        Controller c = new Controller("test12.bin");
        Handler handler = new Handler(c);
        handler.handler();
        MergeSort merge = new MergeSort(c);
        assertEquals(merge.runCounter, 2);
        assertTrue(c.inputBuffer().isEmpty());
        assertNull(merge.heapSorter);
       
    }

}
