import student.TestCase;
import java.nio.ByteBuffer;

import org.junit.Test;


/**
 * @author nivipal
 * @author swatil
 * @version 1.0
 * 
 * This is the testing class for Record
 *
 */
public class RecordTest extends TestCase {

    /**
     * Helper function to convert a long and a double into a record byte array
     * @param id the ID for the record
     * @param key the key for the record
     * @return the key value
     */

    public byte[] convertTobyteArr(long id, double key) {
        byte[] bytes1 = new byte[8];
        byte[] bytes2 = new byte[8];
        ByteBuffer.wrap(bytes1).putLong(id);
        ByteBuffer.wrap(bytes2).putDouble(key);
        byte[] record = new byte[16];
        System.arraycopy( bytes1, 0, record, 0, 8);
        System.arraycopy( bytes2, 0, record, 8, 8);
        return record;
    }
    
/**
 * test method for merg
 */
    @Test
    public void mergeTest() {
        byte[] array = convertTobyteArr(10, 4);
        Record mn = new Record(0, array, 0, 8192);
        assertEquals(mn.getBlockCount(), 0);
        assertEquals(mn.key(), 4, 0.1);
    }


    /**
     * Test method 
     */
    @Test
    public void blkTest() {
        byte[] array = convertTobyteArr(1, 48);
        Record mn = new Record(1, array, 8192, 8192 * 2);
        assertEquals(mn.getBlockCount(), 1);
    }


    /**
     * Test method 
     *      */
    public void setBlkTest() {
        byte[] array = convertTobyteArr(51, 8);
        Record mn = new Record(1, array, 8192, 8192 * 2);
        mn.setBlockCount(4);
        assertEquals(mn.getBlockCount(), 4);
    }


    /**
     * Test method 
     */
    public void getRecTest() {
        byte[] array = convertTobyteArr(51, 8);
        Record mn = new Record(1, array, 8192, 8192 * 2);
        assertEquals(mn.getRecord(), array);
    }


    /**
     * Test method
     */
    public void getPointerTest() {
        byte[] array = convertTobyteArr(51, 8);
        Record mn = new Record(1, array, 8192, 8192 * 2);
        assertEquals(mn.getCurrentPointerPosition(), 8192);
    }


    /**
     * Test method
     */
    public void setPointerTest() {
        byte[] array = convertTobyteArr(5, 28);
        Record mn = new Record(0, array, 0, 8192);
        mn.setCurrentPointerPosition(8192);
        assertEquals(mn.getCurrentPointerPosition(), 8192);
    }


    /**
     * Test method
     */
    public void getStartTet() {
        byte[] array = convertTobyteArr(51, 8);
        Record mn = new Record(1, array, 8192, 8192 * 2);
        assertEquals(mn.getStartPointer(), 8192);
    }


    /**
     * Test method
     */
    public void runStartTest() {
        byte[] array = convertTobyteArr(51, 48);
        Record mn = new Record(1, array, 8192, 8192 * 2);
        mn.setStartPointer(0);
        assertEquals(mn.getStartPointer(), 0);
    }


    /**
     * Test method
     */
    public void getEndTest() {
        byte[] array = convertTobyteArr(61, 8);
        Record mn = new Record(0, array, 0, 8192);
        assertEquals(mn.getEndPointer(), 8192);
    }

    /**
     * Test method
     */
    public void runEndSetTest() {
        byte[] array = convertTobyteArr(9, 58);
        Record mn = new Record(1, array, 8192, 8192 * 2);
        mn.setEndPointer(8192 + (8192 / 2));
        assertEquals(mn.getEndPointer(), 8192 + (8192 / 2));
    }
/**
 * test method
 */
    public void testAppend() {
        RunInformation rf = new RunInformation(0, 0, 0, true);
        rf.setAppend(false);
        boolean value = rf.isAppended();
        assertEquals(false, value);
    }

    /**
     * Test method
     */
    public void testInc() {
        byte[] array = convertTobyteArr(50, 88);
        Record mn = new Record(1, array, 8192, 8192 * 2);
        mn.addToCurrentPosition(16);
        assertEquals(mn.getCurrentPointerPosition(), 8192 + 16);
    }

}
