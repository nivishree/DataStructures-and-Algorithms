import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.LinkedList;
/**
 * 
 *@author Nivishree Palvannan
 *@author Swati Lodha
 * @version 1.0
 *
 */
public class Controller {
    
    private RandomAccessFile inputFile;
    private RandomAccessFile runFile;
    private MinHeap minHeap;
    private LinkedList<RunInformation> runInfo;
    private IOBuffer inputBuffer;
    private IOBuffer outputBuffer;
    
/**
 * constructor
 * @param file string
 * @throws IOException
 */
    public Controller(String file) throws IOException {
        inputBuffer = new IOBuffer();
        outputBuffer = new IOBuffer();
        inputFile = new RandomAccessFile(file, "rw");
        runFile = new RandomAccessFile("runfile.bin", "rw");
        runFile.setLength(8 * 8192);
        inputFile.seek(0);
        runFile.seek(0);
        heapInitializer();
       
    }
    
    /**
     * @return op
     */
    public RandomAccessFile runFile() {
        return runFile;
    }
    
    /**
     * @return heap
     */
    public MinHeap minHeap() {
        return minHeap;
    }
    
    /**
     * @param list of runs
     */
    public void setRunInfo(LinkedList<RunInformation> list) {
        runInfo = list;
    }
    
    
    /**
     * @return run info 
     */
    public LinkedList<RunInformation> getRunInfo() {
        return runInfo;
    }
   
    /**
     * @return ip file
     */
    public RandomAccessFile inputFile() {
        return inputFile;
    }
    
    /**
     * @return input buffer
     */
    public IOBuffer inputBuffer() {
        return inputBuffer;
    }
  
    /**
     * @return output Buffer
     */
    public IOBuffer outputBuffer() {
        return outputBuffer;
    }

    /**
     * initilazing heap values
     * @throws IOException
     */
    private void heapInitializer() throws IOException {
        runInfo = new LinkedList<RunInformation>();
        byte[] heapStore = new byte[8 * 8192];
        this.inputFile.read(heapStore);
        minHeap = new MinHeap(heapStore, 4096, 4096);
        minHeap.makeHeap();
    }
}
