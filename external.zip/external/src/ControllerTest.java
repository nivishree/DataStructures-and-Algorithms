import static org.junit.Assert.*;

import java.io.IOException;
import java.util.LinkedList;

import org.junit.Test;

/**
 * 
 * @author nivip
 * @author swatil
 * @version 1.0
 *
 */

public class ControllerTest {
/**
 * test method
 * @throws IOException 
 */
    @Test
    public void test() throws IOException {
        LinkedList<RunInformation> list = new LinkedList<RunInformation>();
        Controller c = new Controller("file");
        c.setRunInfo(list);
        int value = c.getRunInfo().size();
        assertEquals(value, 0);
    }
}
